from rest_framework.test import APITestCase

from .models import User


class AuthApiTests(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user("mgr", password="pass12345", email="m@example.com")

    def test_register_returns_tokens(self):
        resp = self.client.post("/api/auth/register/", {
            "username": "newuser", "email": "n@example.com",
            "first_name": "Иван", "last_name": "Петров",
            "phone": "+79990000000", "position": "manager",
            "password": "secret123", "password2": "secret123",
        }, format="json")
        self.assertEqual(resp.status_code, 201)
        self.assertIn("access", resp.data)
        self.assertTrue(User.objects.filter(username="newuser").exists())

    def test_register_password_mismatch(self):
        resp = self.client.post("/api/auth/register/", {
            "username": "x", "password": "secret123", "password2": "other123",
        }, format="json")
        self.assertEqual(resp.status_code, 400)

    def test_login_ok_and_me(self):
        resp = self.client.post("/api/auth/login/",
                                {"username": "mgr", "password": "pass12345"}, format="json")
        self.assertEqual(resp.status_code, 200)
        token = resp.data["access"]
        self.client.credentials(HTTP_AUTHORIZATION="Bearer " + token)
        me = self.client.get("/api/auth/me/")
        self.assertEqual(me.status_code, 200)
        self.assertEqual(me.data["username"], "mgr")

    def test_login_wrong_password(self):
        resp = self.client.post("/api/auth/login/",
                                {"username": "mgr", "password": "wrong"}, format="json")
        self.assertEqual(resp.status_code, 400)

    def test_me_requires_token(self):
        self.assertEqual(self.client.get("/api/auth/me/").status_code, 401)
