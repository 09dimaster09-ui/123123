from rest_framework.test import APITestCase

from apps.accounts.models import User
from .models import Client


class ClientApiTests(APITestCase):
    def setUp(self):
        User.objects.create_user("mgr", password="pass12345")
        resp = self.client.post("/api/auth/login/",
                                {"username": "mgr", "password": "pass12345"}, format="json")
        self.client.credentials(HTTP_AUTHORIZATION="Bearer " + resp.data["access"])

    def test_create_client_and_unique_phone(self):
        data = {"full_name": "Иванов Иван", "phone": "+79990000001"}
        self.assertEqual(self.client.post("/api/clients/", data, format="json").status_code, 201)
        dup = self.client.post("/api/clients/", data, format="json")
        self.assertEqual(dup.status_code, 400)
        self.assertEqual(Client.objects.count(), 1)

    def test_search_client(self):
        Client.objects.create(full_name="Петров Пётр", phone="+79990000002")
        Client.objects.create(full_name="Сидоров Сидор", phone="+79990000003")
        resp = self.client.get("/api/clients/?search=Петров")
        self.assertEqual(resp.data["count"], 1)
