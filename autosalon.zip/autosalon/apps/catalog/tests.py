from rest_framework.test import APITestCase

from apps.accounts.models import User
from .models import Brand, Car


class CatalogApiTests(APITestCase):
    def setUp(self):
        User.objects.create_user("mgr", password="pass12345")
        self.brand = Brand.objects.create(name="Toyota", country="Япония")

    def login(self):
        resp = self.client.post("/api/auth/login/",
                                {"username": "mgr", "password": "pass12345"}, format="json")
        self.client.credentials(HTTP_AUTHORIZATION="Bearer " + resp.data["access"])

    def test_cars_require_token(self):
        self.assertEqual(self.client.get("/api/cars/").status_code, 401)

    def test_create_and_filter_car(self):
        self.login()
        resp = self.client.post("/api/cars/", {
            "brand": self.brand.pk, "model": "Camry", "year": 2022, "price": "2500000.00",
        }, format="json")
        self.assertEqual(resp.status_code, 201)
        self.assertEqual(resp.data["status"], "available")

        lst = self.client.get("/api/cars/?status=available")
        self.assertEqual(lst.status_code, 200)
        self.assertEqual(lst.data["count"], 1)
        self.assertEqual(self.client.get("/api/cars/?status=sold").data["count"], 0)

    def test_car_str_and_is_available(self):
        car = Car.objects.create(brand=self.brand, model="Camry", year=2022, price=1)
        self.assertEqual(str(car), "Toyota Camry (2022)")
        self.assertTrue(car.is_available)
