"""МОДУЛЬ 4 (ЗАКАЗЫ): API.

В PDF этот файл не приведён, но config/urls.py подключает apps.orders.urls,
который импортирует OrderViewSet — поэтому он написан здесь.
"""

from rest_framework import viewsets, filters
from rest_framework.decorators import action
from rest_framework.response import Response
from django_filters.rest_framework import DjangoFilterBackend

from .models import Order
from .serializers import OrderSerializer


class OrderViewSet(viewsets.ModelViewSet):
    """CRUD для заказов + завершение/отмена с каскадом на авто.

      POST /api/orders/{id}/complete/ — завершить заказ (покупка → авто «Продан»)
      POST /api/orders/{id}/cancel/   — отменить заказ (авто → «В наличии»)
    """
    queryset = Order.objects.select_related("client", "car", "car__brand", "manager").all()
    serializer_class = OrderSerializer
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ["status", "order_type", "client", "car", "manager"]
    search_fields = ["client__full_name", "car__model"]
    ordering_fields = ["created_at", "total_amount"]

    def perform_create(self, serializer):
        # Менеджер — текущий пользователь (поле manager в сериализаторе read-only)
        serializer.save(manager=self.request.user)

    @action(detail=True, methods=["post"])
    def complete(self, request, pk=None):
        order = self.get_object()
        if order.status in (Order.Status.COMPLETED, Order.Status.CANCELLED):
            return Response({"detail": "Заказ уже закрыт"}, status=400)
        order.complete()
        return Response(self.get_serializer(order).data)

    @action(detail=True, methods=["post"])
    def cancel(self, request, pk=None):
        order = self.get_object()
        if order.status in (Order.Status.COMPLETED, Order.Status.CANCELLED):
            return Response({"detail": "Заказ уже закрыт"}, status=400)
        order.cancel()
        return Response(self.get_serializer(order).data)
