"""Заполнение БД демонстрационными данными для скриншотов.

Запуск: python manage.py seed_demo
"""

from decimal import Decimal

from django.core.management.base import BaseCommand

from apps.accounts.models import User
from apps.catalog.models import Brand, Car
from apps.clients.models import Client
from apps.orders.models import Order


class Command(BaseCommand):
    help = "Добавляет демо-данные: марки, авто, клиентов, заказы и менеджера manager1"

    def handle(self, *args, **options):
        if Car.objects.exists():
            self.stdout.write("Данные уже есть — пропускаю.")
            return

        manager, created = User.objects.get_or_create(
            username="manager1",
            defaults={"first_name": "Пётр", "last_name": "Сидоров",
                      "email": "manager1@example.com", "position": User.Position.MANAGER},
        )
        if created:
            manager.set_password("manager123")
            manager.save()

        brands = {}
        for name, country in [("Toyota", "Япония"), ("BMW", "Германия"),
                              ("Lada", "Россия"), ("Hyundai", "Южная Корея")]:
            brands[name], _ = Brand.objects.get_or_create(name=name, defaults={"country": country})

        cars_data = [
            ("Toyota", "Camry", 2022, "2500000", "Белый", "petrol", "AT", 15000),
            ("Toyota", "RAV4", 2023, "3400000", "Серый", "hybrid", "CVT", 5000),
            ("BMW", "X5", 2021, "6900000", "Чёрный", "diesel", "AT", 32000),
            ("BMW", "3 Series", 2022, "4300000", "Синий", "petrol", "AT", 21000),
            ("Lada", "Vesta", 2023, "1300000", "Красный", "petrol", "MT", 1000),
            ("Hyundai", "Solaris", 2020, "1100000", "Серебристый", "petrol", "AT", 54000),
        ]
        cars = []
        for i, (brand, model, year, price, color, fuel, trans, mileage) in enumerate(cars_data, start=1):
            cars.append(Car.objects.create(
                brand=brands[brand], model=model, year=year, price=Decimal(price),
                color=color, fuel_type=fuel, transmission=trans, mileage=mileage,
                vin=f"VIN{i:014d}",
            ))

        clients = [
            Client.objects.create(full_name="Иванов Иван Иванович", phone="+79990000001",
                                  email="ivanov@example.com", manager=manager),
            Client.objects.create(full_name="Петрова Анна Сергеевна", phone="+79990000002",
                                  email="petrova@example.com", manager=manager),
            Client.objects.create(full_name="Кузнецов Дмитрий Олегович", phone="+79990000003",
                                  manager=manager),
        ]

        # Две завершённые покупки, одна забронированная и один тест-драйв
        for client, car in ((clients[0], cars[0]), (clients[1], cars[2])):
            order = Order.objects.create(client=client, car=car, manager=manager,
                                         order_type=Order.OrderType.PURCHASE,
                                         total_amount=car.price, status=Order.Status.CONFIRMED)
            order.complete()
        Order.objects.create(client=clients[2], car=cars[1], manager=manager,
                             order_type=Order.OrderType.PURCHASE, total_amount=cars[1].price)
        Order.objects.create(client=clients[0], car=cars[4], manager=manager,
                             order_type=Order.OrderType.TEST_DRIVE, total_amount=0)

        self.stdout.write(self.style.SUCCESS(
            "Готово. Менеджер: manager1 / manager123 (для входа в API)."))
