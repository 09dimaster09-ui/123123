"""МОДУЛЬ 4 (ЗАКАЗЫ): Админка."""

from django.contrib import admin
from .models import Order


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ("id", "client", "car", "order_type", "total_amount", "status", "created_at")
    list_filter = ("status", "order_type", "created_at")
    search_fields = ("client__full_name", "car__model")
    readonly_fields = ("created_at", "completed_at")
    actions = ("complete_orders", "cancel_orders")

    # Действия запускают каскад (авто → «Продан» / «В наличии»)
    @admin.action(description="Завершить выбранные заказы")
    def complete_orders(self, request, queryset):
        done = 0
        for order in queryset.exclude(status__in=(Order.Status.COMPLETED, Order.Status.CANCELLED)):
            order.complete()
            done += 1
        self.message_user(request, f"Завершено заказов: {done}")

    @admin.action(description="Отменить выбранные заказы")
    def cancel_orders(self, request, queryset):
        done = 0
        for order in queryset.exclude(status__in=(Order.Status.COMPLETED, Order.Status.CANCELLED)):
            order.cancel()
            done += 1
        self.message_user(request, f"Отменено заказов: {done}")
