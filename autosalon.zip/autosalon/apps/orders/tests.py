from decimal import Decimal

from django.test import TestCase

from apps.accounts.models import User
from apps.catalog.models import Brand, Car
from apps.clients.models import Client
from .models import Order


class OrderCascadeTests(TestCase):
    def setUp(self):
        self.manager = User.objects.create_user("mgr", password="pass12345")
        brand = Brand.objects.create(name="Toyota", country="Япония")
        self.car = Car.objects.create(brand=brand, model="Camry", year=2022, price=Decimal("2500000"))
        self.buyer = Client.objects.create(full_name="Иванов Иван", phone="+79990000001")

    def make_order(self, order_type=Order.OrderType.PURCHASE):
        return Order.objects.create(
            client=self.buyer, car=self.car, manager=self.manager,
            order_type=order_type, total_amount=Decimal("2500000"),
        )

    def test_purchase_reserves_car(self):
        self.make_order()
        self.car.refresh_from_db()
        self.assertEqual(self.car.status, Car.Status.RESERVED)

    def test_test_drive_does_not_reserve(self):
        self.make_order(Order.OrderType.TEST_DRIVE)
        self.car.refresh_from_db()
        self.assertEqual(self.car.status, Car.Status.AVAILABLE)

    def test_complete_marks_car_sold(self):
        order = self.make_order()
        order.complete()
        self.car.refresh_from_db()
        self.assertEqual(order.status, Order.Status.COMPLETED)
        self.assertIsNotNone(order.completed_at)
        self.assertEqual(self.car.status, Car.Status.SOLD)

    def test_cancel_returns_car_to_stock(self):
        order = self.make_order()
        order.cancel()
        self.car.refresh_from_db()
        self.assertEqual(order.status, Order.Status.CANCELLED)
        self.assertEqual(self.car.status, Car.Status.AVAILABLE)
