from decimal import Decimal

from rest_framework.test import APITestCase

from apps.accounts.models import User
from apps.catalog.models import Brand, Car
from apps.clients.models import Client
from apps.orders.models import Order
from .services import ReportService


class ReportsTests(APITestCase):
    def setUp(self):
        self.manager = User.objects.create_user("mgr", password="pass12345")
        brand = Brand.objects.create(name="Toyota", country="Япония")
        self.car = Car.objects.create(brand=brand, model="Camry", year=2022, price=Decimal("2500000"))
        self.buyer = Client.objects.create(full_name="Иванов Иван", phone="+79990000001")

    def test_kpi_after_completed_order(self):
        before = ReportService.kpi(30)
        self.assertEqual(before["sales_count"], 0)
        self.assertEqual(before["in_stock"], 1)

        order = Order.objects.create(
            client=self.buyer, car=self.car, manager=self.manager,
            order_type=Order.OrderType.PURCHASE, total_amount=Decimal("2500000"),
        )
        order.complete()

        after = ReportService.kpi(30)
        self.assertEqual(after["sales_count"], 1)
        self.assertEqual(after["revenue"], 2500000.0)
        self.assertEqual(after["avg_check"], 2500000.0)
        self.assertEqual(after["in_stock"], 0)

    def test_kpi_endpoint_requires_token_and_returns_json(self):
        self.assertEqual(self.client.get("/api/reports/kpi/").status_code, 401)
        resp = self.client.post("/api/auth/login/",
                                {"username": "mgr", "password": "pass12345"}, format="json")
        self.client.credentials(HTTP_AUTHORIZATION="Bearer " + resp.data["access"])
        kpi = self.client.get("/api/reports/kpi/?days=7")
        self.assertEqual(kpi.status_code, 200)
        self.assertEqual(kpi.data["period_days"], 7)
