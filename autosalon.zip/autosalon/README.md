# AutoSalon — ИС «Автосалон», часть 1: web-приложение (Django + DRF + JWT + PostgreSQL)

Модули: accounts (авторизация), catalog (каталог авто), clients (клиенты),
orders (заказы), reports (отчёты). Дашборд — dashboard/app.py (Streamlit).

## Запуск (Windows, PowerShell, из папки проекта)

1. Установить Python 3.12+ и PostgreSQL (пароль пользователя postgres запомнить).
2. Создать БД и пользователя (один раз):

       $env:Path += ";C:\Program Files\PostgreSQL\18\bin"
       psql -U postgres -f setup_db.sql

3. Виртуальное окружение и зависимости:

       python -m venv .venv
       .venv\Scripts\activate
       pip install -r requirements.txt

4. Файл .env уже создан (из .env.example). Параметры БД по умолчанию:
   autosalon_db / autosalon / autosalon_pass, localhost:5432.
5. Миграции и суперпользователь:

       python manage.py makemigrations accounts catalog clients orders
       python manage.py migrate
       python manage.py createsuperuser

6. (по желанию) демо-данные для скриншотов:

       python manage.py seed_demo

7. Запуск сервера: python manage.py runserver
   Админка: http://127.0.0.1:8000/admin/   API: http://127.0.0.1:8000/api/

8. Тесты: python manage.py test

9. Дашборд (в новом терминале, venv активирован). В .env указать
   API_USER и API_PASSWORD (суперпользователь из шага 5), затем:

       streamlit run dashboard/app.py

## Основные эндпоинты

POST /api/auth/register/ · POST /api/auth/login/ · GET /api/auth/me/ · POST /api/auth/token/refresh/
/api/brands/ · /api/cars/ · /api/clients/ · /api/orders/ (+ POST /api/orders/{id}/complete/ и /cancel/)
GET /api/reports/kpi/ · revenue/ · top-models/ · manager-load/ · stock/
