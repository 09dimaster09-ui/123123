import os
from pathlib import Path

import requests
import pandas as pd
import plotly.express as px
import streamlit as st
from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parent.parent / ".env")

API_URL = os.getenv("API_URL", "http://localhost:8000")
API_USER = os.getenv("API_USER", "admin")
API_PASSWORD = os.getenv("API_PASSWORD", "")

st.set_page_config(page_title="Автосалон — Аналитика", page_icon="🚗", layout="wide")
st.title("🚗 Автосалон — Панель руководителя")


# === АВТОРИЗАЦИЯ В API (JWT) ===
# API закрыт токеном, поэтому дашборд сначала входит под пользователем из .env
@st.cache_data(ttl=300)
def get_token():
    resp = requests.post(
        f"{API_URL}/api/auth/login/",
        json={"username": API_USER, "password": API_PASSWORD},
        timeout=10,
    )
    resp.raise_for_status()
    return resp.json()["access"]


def api_get(path, params=None):
    resp = requests.get(
        f"{API_URL}{path}",
        params=params,
        headers={"Authorization": f"Bearer {get_token()}"},
        timeout=10,
    )
    resp.raise_for_status()
    return resp.json()


# === БОКОВАЯ ПАНЕЛЬ ===
with st.sidebar:
    st.header("⚙️ Фильтры")
    days = st.selectbox("Период", [7, 30, 90, 365], index=1,
                        format_func=lambda x: f"{x} дней")
    if st.button("🔄 Обновить"):
        st.cache_data.clear()
        st.rerun()


# ФУНКЦИИ ЗАГРУЗКИ ДАННЫХ ИЗ API
@st.cache_data(ttl=60)
def load_kpi(days):
    return api_get("/api/reports/kpi/", {"days": days})


@st.cache_data(ttl=60)
def load_revenue(days):
    data = api_get("/api/reports/revenue/", {"days": days})
    return pd.DataFrame(data)


@st.cache_data(ttl=60)
def load_top_models():
    return pd.DataFrame(api_get("/api/reports/top-models/"))


@st.cache_data(ttl=60)
def load_manager_load(days):
    return pd.DataFrame(api_get("/api/reports/manager-load/", {"days": days}))


@st.cache_data(ttl=60)
def load_stock():
    return pd.DataFrame(api_get("/api/reports/stock/"))


# KPI-ПЛИТКИ
try:
    kpi = load_kpi(days)
except requests.RequestException as exc:
    st.error(
        f"Не удалось получить данные из API ({API_URL}): {exc}\n\n"
        "Проверьте, что запущен `python manage.py runserver` и в .env указаны "
        "API_USER и API_PASSWORD (логин и пароль существующего пользователя)."
    )
    st.stop()

c1, c2, c3, c4 = st.columns(4)
c1.metric("💰 Выручка", f"{kpi['revenue']:,.0f} ₽")
c2.metric("✅ Продаж", kpi["sales_count"])
c3.metric("📈 Средний чек", f"{kpi['avg_check']:,.0f} ₽")
c4.metric("🚗 В наличии", kpi["in_stock"])

# ГРАФИК ВЫРУЧКИ
st.header("📈 Динамика выручки")
revenue_df = load_revenue(days)
if not revenue_df.empty:
    fig = px.line(revenue_df, x="date", y="total", markers=True)
    st.plotly_chart(fig, use_container_width=True)

# 2 КОЛОНКИ
col1, col2 = st.columns(2)

with col1:
    st.header("🏆 Топ-5 моделей")
    top = load_top_models()
    if not top.empty:
        fig = px.bar(top, x="count", y="model", color="brand", orientation="h")
        st.plotly_chart(fig, use_container_width=True)

with col2:
    st.header("👥 Загрузка менеджеров")
    managers = load_manager_load(days)
    if not managers.empty:
        fig = px.pie(managers, values="orders", names="manager")
        st.plotly_chart(fig, use_container_width=True)

# СКЛАД
st.header("📦 Состояние склада")
stock = load_stock()
if not stock.empty:
    fig = px.pie(stock, values="count", names="status",
                 color_discrete_map={"available": "green", "reserved": "orange", "sold": "red"},
                 color="status")
    st.plotly_chart(fig, use_container_width=True)
