-- Выполнить под пользователем postgres:
--   psql -U postgres -f setup_db.sql
CREATE USER autosalon WITH PASSWORD 'autosalon_pass' CREATEDB;  -- CREATEDB нужен для manage.py test
CREATE DATABASE autosalon_db OWNER autosalon ENCODING 'UTF8' TEMPLATE template0;
\c autosalon_db
GRANT ALL ON SCHEMA public TO autosalon;
