# ams — каркас Django-проекта (Практическая работа №3)

## Запуск (Windows, PowerShell, из папки проекта)

1. Установить Memurai (Redis), порт 6379, и PostgreSQL (пароль для postgres запомнить).
2. Создать БД (один раз):
       $env:Path += ";C:\Program Files\PostgreSQL\18\bin"
       psql -U postgres -f setup_db.sql
3. Виртуальное окружение и зависимости:
       python -m venv .venv
       .venv\Scripts\activate
       pip install -r requirements.txt
4. Миграции и суперпользователь:
       python manage.py makemigrations accounts catalog
       python manage.py migrate
       python manage.py createsuperuser
5. Запуск:
       python manage.py runserver
   Админка: http://localhost:8000/admin/
