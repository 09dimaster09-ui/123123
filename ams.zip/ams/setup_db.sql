-- Выполнить под пользователем postgres:
--   psql -U postgres -f setup_db.sql
CREATE USER ams WITH PASSWORD 'ams';
CREATE DATABASE ams OWNER ams;
\c ams
GRANT ALL ON SCHEMA public TO ams;
